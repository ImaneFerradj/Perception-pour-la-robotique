1 - Pour pouvoir generer la trajectoire souhaitee:
  * charger loa sequence d'images souhaitant etudier dans: Generer_trajectoire.m
2 - Pour etudier les differents descripteurs:
  * charger loa sequence d'images souhaitant etudier dans: Choix_descripteur.m
3 - Pour generer la trajectoire des points d'interet: SURF: 
  * charger loa sequence d'images souhaitant etudier dans: Application_descripteur.m